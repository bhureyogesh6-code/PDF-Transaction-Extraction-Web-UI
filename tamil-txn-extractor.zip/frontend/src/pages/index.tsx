import { useRouter } from 'next/router';
import { useState } from 'react';

export default function Login() {
  const router = useRouter();
  const [user, setUser] = useState('');
  const handleLogin = (e) => {
    e.preventDefault();
    if (user.trim()) {
      localStorage.setItem('demo_token', 'demo');
      router.push('/upload');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <form onSubmit={handleLogin} className="w-full max-w-md p-8 bg-white rounded shadow">
        <h1 className="text-xl mb-4">Demo Login</h1>
        <input value={user} onChange={e=>setUser(e.target.value)} placeholder="username" className="w-full p-2 border mb-3"/>
        <button className="w-full p-2 bg-blue-600 text-white rounded">Login (stub)</button>
        <p className="mt-3 text-sm text-gray-500">Use any username. Demo token stored locally.</p>
      </form>
    </div>
  );
}
