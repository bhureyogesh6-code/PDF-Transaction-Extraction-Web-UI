import { useEffect, useState } from 'react';
import axios from 'axios';
import ResultsTable from '../components/ResultsTable';
import PDFPreview from '../components/PDFPreview';
import { useRouter } from 'next/router';

export default function Upload() {
  const router = useRouter();
  useEffect(()=> {
    if (!localStorage.getItem('demo_token')) router.push('/');
  }, []);
  const [file, setFile] = useState(null);
  const [results, setResults] = useState([]);
  const [pdfUrl, setPdfUrl] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return alert('Select a PDF');
    const fd = new FormData();
    fd.append('file', file);
    setLoading(true);
    try {
      const r = await axios.post('http://localhost:3001/api/upload', fd, { headers: { 'Content-Type': 'multipart/form-data' }});
      setResults(r.data.inserted || []);
      setPdfUrl(URL.createObjectURL(file));
    } catch (err) {
      alert('Upload failed: ' + (err?.response?.data?.message || err.message));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 min-h-screen bg-gray-100">
      <div className="max-w-6xl mx-auto grid grid-cols-3 gap-6">
        <div className="col-span-1 bg-white p-4 rounded shadow">
          <h2 className="font-semibold mb-2">Upload Tamil PDF</h2>
          <form onSubmit={handleUpload}>
            <input type="file" accept="application/pdf" onChange={(e)=>setFile(e.target.files?.[0]||null)} />
            <button className="mt-3 px-4 py-2 bg-green-600 text-white rounded">{loading ? 'Processing...' : 'Upload & Parse'}</button>
          </form>
          <div className="mt-4">
            <h3 className="text-sm font-medium">Filters</h3>
            <p className="text-xs text-gray-500">Use the search API to query the DB (example: /api/transactions?buyer=Ravi)</p>
          </div>
        </div>

        <div className="col-span-2 bg-white p-4 rounded shadow">
          <h2 className="font-semibold mb-2">Results & Preview</h2>
          <div className="flex gap-4">
            <div className="flex-1">
              <ResultsTable rows={results} />
            </div>
            <div style={{width: 400}} className="border p-2">
              <PDFPreview url={pdfUrl} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
