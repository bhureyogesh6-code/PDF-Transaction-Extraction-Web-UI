export default function ResultsTable({ rows = [] }) {
  return (
    <div className="overflow-auto">
      <table className="w-full table-fixed border-collapse">
        <thead>
          <tr className="bg-gray-100 text-left">
            <th className="p-2">ID</th>
            <th className="p-2">Buyer (EN)</th>
            <th className="p-2">Seller (EN)</th>
            <th className="p-2">Survey</th>
            <th className="p-2">Plot</th>
            <th className="p-2">Doc</th>
            <th className="p-2">Date</th>
            <th className="p-2">Value</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={r.id || i} className="border-t">
              <td className="p-2">{r.id}</td>
              <td className="p-2">{r.buyer_en || r.buyer_tn}</td>
              <td className="p-2">{r.seller_en || r.seller_tn}</td>
              <td className="p-2">{r.survey_no}</td>
              <td className="p-2">{r.house_no}</td>
              <td className="p-2">{r.document_no}</td>
              <td className="p-2">{r.doc_date}</td>
              <td className="p-2">{r.value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
