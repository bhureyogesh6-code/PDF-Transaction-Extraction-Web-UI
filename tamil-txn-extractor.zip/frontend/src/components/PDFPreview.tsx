export default function PDFPreview({ url }) {
  if (!url) return <div className="text-sm text-gray-500">No PDF loaded</div>;
  return (
    <iframe src={url} width="100%" height="600" />
  );
}
