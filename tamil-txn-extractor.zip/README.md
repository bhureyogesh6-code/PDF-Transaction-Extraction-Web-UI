# Tamil Transaction Extractor & Web UI

This project ingests Tamil real-estate transaction PDFs, extracts fields, translates Tamil fields to English, stores transactions in PostgreSQL (Drizzle ORM) and provides a Next.js UI for upload, preview and search.

## Structure
- backend/: NestJS backend accepting PDF uploads, extracting/ocr/translating and storing to Postgres.
- frontend/: Next.js + Tailwind UI for upload & results preview.

## Setup (local)
1. Install Postgres and create DB:
   createdb tamil_txns

2. Backend:
   cd backend
   npm install
   cp ../.env.example .env
   npm run start:dev

3. Migrations:
   psql $DATABASE_URL -f backend/migrations/0001_create_transactions.sql

4. Frontend:
   cd frontend
   npm install
   npm run dev

## Notes
- The parser uses heuristics and will need tuning for varied PDF layouts.
- For OCR, using system Tesseract + pdftoppm is recommended for production.
