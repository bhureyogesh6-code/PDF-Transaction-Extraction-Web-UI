import { pgTable, serial, text, timestamp, varchar } from 'drizzle-orm/pg-core';

export const transactions = pgTable('transactions', {
  id: serial('id').primaryKey(),
  buyer_tn: text('buyer_tn'),
  seller_tn: text('seller_tn'),
  buyer_en: text('buyer_en'),
  seller_en: text('seller_en'),
  house_no: varchar('house_no', { length: 64 }),
  survey_no: varchar('survey_no', { length: 64 }),
  document_no: varchar('document_no', { length: 64 }),
  doc_date: varchar('doc_date', { length: 64 }),
  value: varchar('value', { length: 128 }),
  raw_text: text('raw_text'),
  created_at: timestamp('created_at').defaultNow(),
});
