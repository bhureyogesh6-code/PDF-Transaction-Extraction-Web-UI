import { Injectable } from '@nestjs/common';
import { pdfToTextAndOcr } from './parser/pdf-parser';
import { translateText } from './parser/translator';
import { db } from '../db/drizzle';
import { transactions } from '../db/schema';

@Injectable()
export class TransactionsService {
  async handleUpload(file: Express.Multer.File) {
    if (!file) throw new Error('No file uploaded');

    const extracted = await pdfToTextAndOcr(file.buffer);
    const parsed = this.parseTransactions(extracted);

    const translated = await Promise.all(
      parsed.map(async (tx) => {
        const transBuyer = await translateText(tx.buyer);
        const transSeller = await translateText(tx.seller);
        return {
          ...tx,
          buyer_en: transBuyer,
          seller_en: transSeller,
        };
      }),
    );

    const inserted = [];
    for (const tx of translated) {
      const res = await db.insert(transactions).values({
        buyer_tn: tx.buyer,
        seller_tn: tx.seller,
        buyer_en: tx.buyer_en,
        seller_en: tx.seller_en,
        house_no: tx.houseNo,
        survey_no: tx.surveyNo,
        document_no: tx.docNo,
        doc_date: tx.date,
        value: tx.value,
        raw_text: tx.rawText,
      }).returning();
      inserted.push(res[0] || res);
    }

    return { inserted, count: inserted.length };
  }

  parseTransactions(fullText: string) {
    const blocks = fullText.split(/\n{2,}/).map(s=>s.trim()).filter(Boolean);
    const results = [];
    for (const block of blocks) {
      const docNoMatch = block.match(/(\d{1,4}\/\d{4})/);
      const dateMatch = block.match(/(\d{2}[-\/\s]\w+[-\/\s]\d{4}|\d{2}[-\/]\d{2}[-\/]\d{4})/);
      const valueMatch = block.match(/ரூ\.\s?[\d,]+/);
      const surveyMatch = block.match(/Survey No\.|புல எண்[:\s]*([\d\/]+)/i) || block.match(/Survey No[:\s]*([\d\/]+)/i);
      const houseMatch = block.match(/Plot No\.|Plot No[:\s]*([\d\/]+)/i) || block.match(/Plot No[:\s]*([\d\/]+)/i);
      const lines = block.split('\n').map(l=>l.trim()).filter(Boolean);
      const maybeBuyer = lines[ lines.length - 2 ] || '';
      const maybeSeller = lines[ lines.length - 3 ] || '';

      results.push({
        rawText: block,
        docNo: docNoMatch ? docNoMatch[1] : '',
        date: dateMatch ? dateMatch[1] : '',
        value: valueMatch ? valueMatch[0] : '',
        surveyNo: surveyMatch ? surveyMatch[1] : '',
        houseNo: houseMatch && houseMatch[1] ? houseMatch[1] : (lines.find(l=>/Plot No|Plot|Plot No\./i.test(l)) || ''),
        buyer: maybeBuyer,
        seller: maybeSeller,
      });
    }
    return results;
  }

  async search(filters: { buyer?:string, seller?:string, houseNo?:string, surveyNo?:string, docNo?:string}) {
    if (!filters.buyer && !filters.seller && !filters.houseNo && !filters.surveyNo && !filters.docNo) {
      return db.select().from(transactions).orderBy(transactions.created_at.desc).limit(500);
    }
    const q = db.select().from(transactions).limit(500);
    return q;
  }
}
