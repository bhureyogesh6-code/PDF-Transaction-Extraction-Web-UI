import pdf from 'pdf-parse';
import Tesseract from 'tesseract.js';

export async function pdfToTextAndOcr(buffer: Buffer) {
  try {
    const data = await pdf(buffer);
    if (data && data.text && data.text.trim().length > 200) {
      return data.text;
    }
  } catch (e) {
    console.warn('pdf-parse failed, will fallback to OCR', e);
  }

  const { data: { text } } = await Tesseract.recognize(buffer, 'tam', {
    logger: m => {}
  });
  return text;
}
