import fetch from 'node-fetch';

const TRANSLATE_URL = process.env.LIBRETRANSLATE_URL || 'https://libretranslate.com/translate';
const TRANSLATE_API_KEY = process.env.LIBRETRANSLATE_KEY || '';

export async function translateText(text: string) {
  if (!text || text.trim().length === 0) return '';
  try {
    const res = await fetch(TRANSLATE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(TRANSLATE_API_KEY ? { 'Authorization': `Bearer ${TRANSLATE_API_KEY}` } : {}),
      },
      body: JSON.stringify({
        q: text,
        source: 'ta',
        target: 'en',
        format: 'text'
      })
    });
    const j = await res.json();
    return j.translatedText || text;
  } catch (e) {
    console.warn('translation failed', e);
    return text;
  }
}
