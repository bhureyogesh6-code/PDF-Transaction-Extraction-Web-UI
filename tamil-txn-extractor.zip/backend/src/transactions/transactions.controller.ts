import { Controller, Post, UseInterceptors, UploadedFile, Get, Query } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { TransactionsService } from './transactions.service';
import * as multer from 'multer';

@Controller('api')
export class TransactionsController {
  constructor(private readonly svc: TransactionsService) {}

  @Post('upload')
  @UseInterceptors(FileInterceptor('file', { storage: multer.memoryStorage() }))
  async upload(@UploadedFile() file: Express.Multer.File) {
    return this.svc.handleUpload(file);
  }

  @Get('transactions')
  async list(
    @Query('buyer') buyer?: string,
    @Query('seller') seller?: string,
    @Query('houseNo') houseNo?: string,
    @Query('surveyNo') surveyNo?: string,
    @Query('docNo') docNo?: string,
  ) {
    return this.svc.search({ buyer, seller, houseNo, surveyNo, docNo });
  }
}
