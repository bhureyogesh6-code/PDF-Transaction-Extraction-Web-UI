CREATE TABLE transactions (
  id SERIAL PRIMARY KEY,
  buyer_tn TEXT,
  seller_tn TEXT,
  buyer_en TEXT,
  seller_en TEXT,
  house_no VARCHAR(64),
  survey_no VARCHAR(64),
  document_no VARCHAR(64),
  doc_date VARCHAR(64),
  value VARCHAR(128),
  raw_text TEXT,
  created_at TIMESTAMP DEFAULT now()
);
